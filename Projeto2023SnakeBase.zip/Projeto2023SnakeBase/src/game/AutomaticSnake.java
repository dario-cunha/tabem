package game;

import java.util.LinkedList;
import java.util.List;

import javax.swing.text.Position;

import environment.BoardPosition;
import environment.Cell;
import environment.LocalBoard;

public class AutomaticSnake extends Snake {
	public AutomaticSnake(int id, LocalBoard board) {
		super(id,board);

	}



	@Override
	public void run() {
		doInitialPositioning();
		System.err.println("initial size:"+cells.size());
		try {
			cells.getLast().request(this);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BoardPosition golo = getBoard().getGoalPosition();
		Cell cabeca = cells.getLast();
		double up = cabeca.getPosition().getCellAbove().distanceTo(golo);
		double down = cabeca.getPosition().getCellBelow().distanceTo(golo);
		double left = cabeca.getPosition().getCellLeft().distanceTo(golo);
		double right = cabeca.getPosition().getCellRight().distanceTo(golo);

		double[] lista = {up, down, left, right};
		double minimo = Double.MAX_VALUE;
		int direcao = -1;

		for (int i =0; i < 4; i++) {
			if(lista[i] < minimo)
				minimo = lista[i];
		}



	}
	

	
}
